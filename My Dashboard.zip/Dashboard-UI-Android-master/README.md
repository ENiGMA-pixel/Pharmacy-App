# Dashboard-UI-Android
Minimal Dashboard UI in Android Studio using GridLayout!
![center](https://cdn.dribbble.com/users/2352042/screenshots/9066838/media/4ac122939ed790f35ea05ec839fc923c.png)
